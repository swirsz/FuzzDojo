#include "rar.hpp"
#include <string>
#include <vector>

// Helper to reset global state if needed.
// In many versions of Unrar, ErrHandler is a global object that needs cleaning.
void ResetGlobalState() {
    ErrHandler.Clean();
}

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    if (size == 0) return 0;

    // 1. Create the CommandData object
    CommandData *Cmd = new CommandData;

    // FIX 1: Command is a raw array (wchar_t[2064]), not a class.
    // We cannot call .clear(). We must set the first character to null to empty it.
    Cmd->Command[0] = 0;

    // FIX 2: Added <string> header above so std::string and std::wstring work.
    std::string raw_input(reinterpret_cast<const char*>(data), size);
    std::wstring global_args;

    // Convert raw bytes to wide string (casting char to wchar_t)
    for (char c : raw_input) {
        global_args += (wchar_t)c;
    }

    // 3. Tokenize manually by spaces to simulate argv parsing
    size_t pos = 0;
    while (pos < global_args.size()) {
        size_t next_space = global_args.find(L' ', pos);
        if (next_space == std::wstring::npos) {
            next_space = global_args.size();
        }

        if (next_space > pos) {
            std::wstring arg = global_args.substr(pos, next_space - pos);

            try {
                // Pass the C-string version of the argument to unrar
                Cmd->ParseArg(const_cast<wchar_t*>(arg.c_str()));
            } catch (...) {
                // Ignore parsing errors to keep fuzzing
            }
        }
        pos = next_space + 1;
    }

    // 4. Trigger post-parsing validation
    try {
        Cmd->ParseDone();
    } catch (...) {}

    delete Cmd;
    ResetGlobalState();

    return 0;
}
