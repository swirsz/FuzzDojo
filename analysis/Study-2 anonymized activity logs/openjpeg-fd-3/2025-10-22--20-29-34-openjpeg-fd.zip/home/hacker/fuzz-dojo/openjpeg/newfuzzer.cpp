// improved_fuzz_opj_roundtrip.cpp
// Based on the harness you provided - exercises extra OpenJPEG paths:
//  - opj_get_cstr_info / opj_get_cstr_index
//  - light psImage component manipulation
//  - multiple opj_set_decode_area + opj_decode calls
//  - round-trip encode (J2K) writing to /dev/null

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>

#include "openjpeg.h"

extern "C" int LLVMFuzzerInitialize(int* argc, char*** argv);
extern "C" int LLVMFuzzerTestOneInput(const uint8_t *buf, size_t len);

#define NUM_COMPS_MAX 4

typedef struct {
    const uint8_t* pabyData;
    size_t         nCurPos;
    size_t         nLength;
} MemFile;

static INLINE OPJ_UINT32 opj_uint_max(OPJ_UINT32  a, OPJ_UINT32  b)
{
    return (a > b) ? a : b;
}

static INLINE OPJ_UINT32 opj_uint_min(OPJ_UINT32  a, OPJ_UINT32  b)
{
    return (a < b) ? a : b;
}

static void error_callback(const char *msg, void *client_data)
{
    (void)client_data;
    fprintf(stdout, "[ERROR] %s", msg);
}

static void warning_callback(const char *msg, void *client_data)
{
    (void)client_data;
    fprintf(stdout, "[WARNING] %s", msg);
}
/**
sample debug callback expecting no client object
*/
static void info_callback(const char *msg, void *client_data)
{
    (void)client_data;
    fprintf(stdout, "[INFO] %s", msg);
}

static OPJ_SIZE_T ReadCallback(void* pBuffer, OPJ_SIZE_T nBytes, void *pUserData)
{
    MemFile* memFile = (MemFile*)pUserData;
    if (memFile->nCurPos >= memFile->nLength) {
        return (OPJ_SIZE_T)-1;
    }
    if (nBytes == 0) {
        return (OPJ_SIZE_T)-1;
    }
    size_t remaining = memFile->nLength - memFile->nCurPos;
    size_t toRead = (nBytes > remaining) ? remaining : (size_t)nBytes;
    memcpy(pBuffer, memFile->pabyData + memFile->nCurPos, toRead);
    memFile->nCurPos += toRead;
    return (OPJ_SIZE_T)toRead;
}

static OPJ_BOOL SeekCallback(OPJ_OFF_T nBytes, void * pUserData)
{
    MemFile* memFile = (MemFile*)pUserData;
    if (nBytes < 0 || (size_t)nBytes > memFile->nLength) {
        return OPJ_FALSE;
    }
    memFile->nCurPos = (size_t)nBytes;
    return OPJ_TRUE;
}

static OPJ_OFF_T SkipCallback(OPJ_OFF_T nBytes, void * pUserData)
{
    MemFile* memFile = (MemFile*)pUserData;
    if (nBytes < 0) {
        return -1;
    }
    size_t skip = (size_t)nBytes;
    size_t remaining = (memFile->nLength > memFile->nCurPos) ? (memFile->nLength - memFile->nCurPos) : 0;
    size_t actual = (skip > remaining) ? remaining : skip;
    memFile->nCurPos += actual;
    return (OPJ_OFF_T)actual;
}

int LLVMFuzzerInitialize(int* /*argc*/, char*** argv)
{
    (void)argv;
    return 0;
}

static const unsigned char jpc_header[] = {0xff, 0x4f};

int LLVMFuzzerTestOneInput(const uint8_t *buf, size_t len)
{
    opj_cparameters_t l_param;
    opj_codec_t * l_codec;
    opj_image_t * l_image;
    opj_image_cmptparm_t l_params [NUM_COMPS_MAX];
    opj_stream_t * l_stream;
    OPJ_UINT32 l_nb_tiles_width, l_nb_tiles_height, l_nb_tiles;
    OPJ_UINT32 l_data_size;
    opj_image_cmptparm_t * l_current_param_ptr;
    OPJ_UINT32 i;
    OPJ_BYTE *l_data;

    OPJ_UINT32 num_comps;
    int image_width;
    int image_height;
    int tile_width;
    int tile_height;
    int comp_prec;
    int irreversible;
    const char *output_file;
    int cblockw_init = 64;
    int cblockh_init = 64;
    int numresolution = 6;
    OPJ_UINT32 offsetx = 0;
    OPJ_UINT32 offsety = 0;
    int quality_loss = 1;
    int is_rand = 0;

    opj_set_default_encoder_parameters(&l_param);
    num_comps = 3;
    image_width = 500;
    image_height = 500;
    tile_width = 250;
    tile_height = 250;
    comp_prec = 8;
    irreversible = 1;
    output_file = "test.j2k";

    l_nb_tiles_width = (offsetx + (OPJ_UINT32)image_width +
                        (OPJ_UINT32)tile_width - 1) / (OPJ_UINT32)tile_width;
    l_nb_tiles_height = (offsety + (OPJ_UINT32)image_height +
                         (OPJ_UINT32)tile_height - 1) / (OPJ_UINT32)tile_height;
    l_nb_tiles = l_nb_tiles_width * l_nb_tiles_height;
    l_data_size = (OPJ_UINT32)tile_width * (OPJ_UINT32)tile_height *
                  (OPJ_UINT32)num_comps * (OPJ_UINT32)(comp_prec / 8);
    
    if (len < l_data_size){
        //printf("RET1\n");
        return 0;
    }

    l_data = (OPJ_BYTE*) malloc(l_data_size * sizeof(OPJ_BYTE));
    if (l_data == NULL) {
        printf("RET2\n");
        return 1;
    }
    fprintf(stdout,
            "Encoding random values -> keep in mind that this is very hard to compress\n");
    for (i = 0; i < l_data_size; ++i) {
        l_data[i] = (OPJ_BYTE)buf[i];
    }

    l_param.tcp_numlayers = 1;
    l_param.cp_fixed_quality = 1;
    l_param.tcp_distoratio[0] = 20;

    l_param.cp_tx0 = 0;
    l_param.cp_ty0 = 0;
    /* tile size, we are using tile based encoding */
    l_param.tile_size_on = OPJ_TRUE;
    l_param.cp_tdx = tile_width;
    l_param.cp_tdy = tile_height;

    /* code block size */
    l_param.cblockw_init = cblockw_init;
    l_param.cblockh_init = cblockh_init;

    /* use irreversible encoding ?*/
    l_param.irreversible = irreversible;

    l_param.numresolution = numresolution;

    /** progression order to use*/
    /** OPJ_LRCP, OPJ_RLCP, OPJ_RPCL, PCRL, CPRL */
    l_param.prog_order = OPJ_LRCP;

    l_current_param_ptr = l_params;
    for (i = 0; i < num_comps; ++i) {
        /* do not bother bpp useless */
        /*l_current_param_ptr->bpp = COMP_PREC;*/
        l_current_param_ptr->dx = 1;
        l_current_param_ptr->dy = 1;

        l_current_param_ptr->h = (OPJ_UINT32)image_height;
        l_current_param_ptr->w = (OPJ_UINT32)image_width;

        l_current_param_ptr->sgnd = 0;
        l_current_param_ptr->prec = (OPJ_UINT32)comp_prec;

        l_current_param_ptr->x0 = offsetx;
        l_current_param_ptr->y0 = offsety;

        ++l_current_param_ptr;
    }

    /* should we do j2k or jp2 ?*/
    len = strlen(output_file);
    if (strcmp(output_file + len - 4, ".jp2") == 0) {
        l_codec = opj_create_compress(OPJ_CODEC_JP2);
    } else {
        l_codec = opj_create_compress(OPJ_CODEC_J2K);
    }
    if (!l_codec) {
        free(l_data);
        printf("codec failed\n");
        return 1;
    }

    /* catch events using our callbacks and give a local context */
    opj_set_info_handler(l_codec, info_callback, 00);
    opj_set_warning_handler(l_codec, warning_callback, 00);
    opj_set_error_handler(l_codec, error_callback, 00);

    l_image = opj_image_tile_create(num_comps, l_params, OPJ_CLRSPC_SRGB);
    if (! l_image) {
        free(l_data);
        opj_destroy_codec(l_codec);
        printf("img failed\n");
        return 1;
    }

    l_image->x0 = offsetx;
    l_image->y0 = offsety;
    l_image->x1 = offsetx + (OPJ_UINT32)image_width;
    l_image->y1 = offsety + (OPJ_UINT32)image_height;
    l_image->color_space = OPJ_CLRSPC_SRGB;

    if (! opj_setup_encoder(l_codec, &l_param, l_image)) {
        fprintf(stderr, "ERROR -> test_tile_encoder: failed to setup the codec!\n");
        opj_destroy_codec(l_codec);
        opj_image_destroy(l_image);
        free(l_data);
        printf("setup failed\n");
        return 1;
    }

    l_stream = opj_stream_create_default_file_stream(output_file, OPJ_FALSE);
    if (! l_stream) {
        fprintf(stderr,
                "ERROR -> test_tile_encoder: failed to create the stream from the output file %s !\n",
                output_file);
        opj_destroy_codec(l_codec);
        opj_image_destroy(l_image);
        free(l_data);
        return 1;
    }

    if (! opj_start_compress(l_codec, l_image, l_stream)) {
        fprintf(stderr, "ERROR -> test_tile_encoder: failed to start compress!\n");
        opj_stream_destroy(l_stream);
        opj_destroy_codec(l_codec);
        opj_image_destroy(l_image);
        free(l_data);
        return 1;
    }

    for (i = 0; i < l_nb_tiles; ++i) {
        OPJ_UINT32 tile_y = i / l_nb_tiles_width;
        OPJ_UINT32 tile_x = i % l_nb_tiles_width;
        OPJ_UINT32 tile_x0 = opj_uint_max(l_image->x0, tile_x * (OPJ_UINT32)tile_width);
        OPJ_UINT32 tile_y0 = opj_uint_max(l_image->y0,
                                          tile_y * (OPJ_UINT32)tile_height);
        OPJ_UINT32 tile_x1 = opj_uint_min(l_image->x1,
                                          (tile_x + 1) * (OPJ_UINT32)tile_width);
        OPJ_UINT32 tile_y1 = opj_uint_min(l_image->y1,
                                          (tile_y + 1) * (OPJ_UINT32)tile_height);
        OPJ_UINT32 tilesize = (tile_x1 - tile_x0) * (tile_y1 - tile_y0) *
                              (OPJ_UINT32)num_comps * (OPJ_UINT32)(comp_prec / 8);
        if (! opj_write_tile(l_codec, i, l_data, tilesize, l_stream)) {
            fprintf(stderr, "ERROR -> test_tile_encoder: failed to write the tile %d!\n",
                    i);
            opj_stream_destroy(l_stream);
            opj_destroy_codec(l_codec);
            opj_image_destroy(l_image);
            free(l_data);
            return 1;
        }
    }

    if (! opj_end_compress(l_codec, l_stream)) {
        fprintf(stderr, "ERROR -> test_tile_encoder: failed to end compress!\n");
        opj_stream_destroy(l_stream);
        opj_destroy_codec(l_codec);
        opj_image_destroy(l_image);
        free(l_data);
        return 1;
    }

    opj_stream_destroy(l_stream);
    opj_destroy_codec(l_codec);
    opj_image_destroy(l_image);

    free(l_data);

    /* Print profiling*/
    /*PROFPRINT();*/

    return 0;
}
    // if (!buf || len < sizeof(jpc_header)) {
    //     return 0;
    // }

    // // only try on what looks like a J2K/JPC header
    // if (memcmp(buf, jpc_header, sizeof(jpc_header)) != 0) {
    //     return 0;
    // }

    // opj_codec_t* pCodec = opj_create_decompress(OPJ_CODEC_J2K);
    // if (!pCodec) return 0;
    // opj_set_info_handler(pCodec, InfoCallback, NULL);
    // opj_set_warning_handler(pCodec, WarningCallback, NULL);
    // opj_set_error_handler(pCodec, ErrorCallback, NULL);

    // opj_dparameters_t parameters;
    // opj_set_default_decoder_parameters(&parameters);

    // if (!opj_setup_decoder(pCodec, &parameters)) {
    //     opj_destroy_codec(pCodec);
    //     return 0;
    // }

    // opj_stream_t *pStream = opj_stream_create(1024, OPJ_TRUE);
    // if (!pStream) {
    //     opj_destroy_codec(pCodec);
    //     return 0;
    // }

    // MemFile memFile;
    // memFile.pabyData = buf;
    // memFile.nLength = len;
    // memFile.nCurPos = 0;

    // opj_stream_set_user_data_length(pStream, len);
    // opj_stream_set_read_function(pStream, ReadCallback);
    // opj_stream_set_seek_function(pStream, SeekCallback);
    // opj_stream_set_skip_function(pStream, SkipCallback);
    // opj_stream_set_user_data(pStream, &memFile, NULL);

    // opj_image_t * psImage = NULL;
    // if (!opj_read_header(pStream, pCodec, &psImage)) {
    //     // header failed
    //     opj_stream_destroy(pStream);
    //     opj_destroy_codec(pCodec);
    //     opj_image_destroy(psImage);
    //     return 0;
    // }

    // // bounds
    // OPJ_UINT32 width = psImage->x1 > psImage->x0 ? (OPJ_UINT32)(psImage->x1 - psImage->x0) : 0;
    // OPJ_UINT32 height = psImage->y1 > psImage->y0 ? (OPJ_UINT32)(psImage->y1 - psImage->y0) : 0;

    // // clamp decode region to modest size to avoid huge memory usage during fuzzing
    // OPJ_UINT32 width_to_read = (width == 0) ? 0 : (width > 1024 ? 1024 : width);
    // OPJ_UINT32 height_to_read = (height == 0) ? 0 : (height > 1024 ? 1024 : height);

    // // decode the selected area once
    // if (width_to_read > 0 && height_to_read > 0 &&
    //     opj_set_decode_area(pCodec, psImage, psImage->x0, psImage->y0,
    //                         psImage->x0 + width_to_read, psImage->y0 + height_to_read)) {
    //     (void)opj_decode(pCodec, pStream, psImage);
    // }

    // // Query codestream info (may be NULL)
    // opj_codestream_info_v2_t* cstr_info = opj_get_cstr_info(pCodec);
    // if (cstr_info) {
    //     opj_destroy_cstr_info(&cstr_info);
    // }

    // // Query codestream index (may be NULL)
    // opj_codestream_index_t* cstr_index = opj_get_cstr_index(pCodec);
    // if (cstr_index) {
    //     opj_destroy_cstr_index(&cstr_index);
    // }
    // FILE *f = fopen("/dev/null", "w");
    // if (f) {
    //     opj_dump_codec(pCodec, OPJ_TRUE, f);
    //     fclose(f);
    // }

    // // // --- Round-trip encode (J2K) writing to /dev/null ---
    // // Create compressor
    // opj_codec_t* enc = opj_create_compress(OPJ_CODEC_J2K);
    // if (enc && psImage) {
    //     opj_set_info_handler(enc, InfoCallback, NULL);
    //     opj_set_warning_handler(enc, WarningCallback, NULL);
    //     opj_set_error_handler(enc, ErrorCallback, NULL);

    //     opj_cparameters_t cparams;
    //     opj_set_default_encoder_parameters(&cparams);
    //     // use some safe defaults (lossless-ish)
    //     cparams.tcp_numlayers = 1;
    //     cparams.cp_disto_alloc = 1;
    //     cparams.irreversible = 0;

    //     // Setup encoder with image
    //     if (opj_setup_encoder(enc, &cparams, psImage)) {
    //         // create a file stream to /dev/null (platform: POSIX). Using OPJ_FALSE: write-only.
    //         opj_stream_t* outStream = opj_stream_create_default_file_stream("/dev/null", OPJ_FALSE);
    //         if (outStream) {
    //             if (opj_start_compress(enc, psImage, outStream)) {
    //                 // encode (may fail for some images but that's fine)
    //                 (void)opj_encode(enc, outStream);
    //                 opj_end_compress(enc, outStream);
    //             }
    //             opj_stream_destroy(outStream);
    //         }
    //     }
    //     opj_destroy_codec(enc);
    // }

    // // cleanup decompress-side properly
    // (void)opj_end_decompress(pCodec, pStream);
    // opj_stream_destroy(pStream);
    // opj_destroy_codec(pCodec);
    // opj_image_destroy(psImage);

//     return 0;
// }
