#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <limits.h>

#include "openjpeg.h"
#include <zlib.h>
#include <png.h>



extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t len);

typedef struct {
    const uint8_t* pabyData;
    size_t         nCurPos;
    size_t         nLength;
} MemFile;

#define PNG_DFMT 17
#define J2K_CFMT 0

static void ErrorCallback(const char * msg, void *)
{
    (void)msg;
    //fprintf(stderr, "%s\n", msg);
}


static void WarningCallback(const char *, void *)
{
}

static void InfoCallback(const char *, void *)
{
}

static OPJ_SIZE_T ReadCallback(void* pBuffer, OPJ_SIZE_T nBytes,
                               void *pUserData)
{
    MemFile* memFile = (MemFile*)pUserData;
    //printf("want to read %d bytes at %d\n", (int)memFile->nCurPos, (int)nBytes);
    if (memFile->nCurPos >= memFile->nLength) {
        return -1;
    }
    if (memFile->nCurPos + nBytes >= memFile->nLength) {
        size_t nToRead = memFile->nLength - memFile->nCurPos;
        memcpy(pBuffer, memFile->pabyData + memFile->nCurPos, nToRead);
        memFile->nCurPos = memFile->nLength;
        return nToRead;
    }
    if (nBytes == 0) {
        return -1;
    }
    memcpy(pBuffer, memFile->pabyData + memFile->nCurPos, nBytes);
    memFile->nCurPos += nBytes;
    return nBytes;
}

static OPJ_BOOL SeekCallback(OPJ_OFF_T nBytes, void * pUserData)
{
    MemFile* memFile = (MemFile*)pUserData;
    //printf("seek to %d\n", (int)nBytes);
    memFile->nCurPos = nBytes;
    return OPJ_TRUE;
}

static OPJ_OFF_T SkipCallback(OPJ_OFF_T nBytes, void * pUserData)
{
    MemFile* memFile = (MemFile*)pUserData;
    memFile->nCurPos += nBytes;
    return nBytes;
}


static const unsigned char jpc_header[] = {0xff, 0x4f};
static const unsigned char jp2_box_jp[] = {0x6a, 0x50, 0x20, 0x20}; /* 'jP  ' */

// encode png to j2k
#define PNG_HDR_SIZE 8
static const unsigned char png_header[8] =  {137, 80, 78, 71, 13, 10, 26, 10};

int LLVMFuzzerTestOneInput(const uint8_t *data, size_t len)
{
    if ((len != PNG_HDR_SIZE) ||
        (memcmp(data, png_header, sizeof(png_header)) != 0))
    {
        return 0;
    }

    const char * v = opj_version();
    //puts(v);

    /* encoder */
    OPJ_BOOL bSuccess;

    // CREATE IMAGE
    opj_cparameters_t cparameters;
    opj_set_default_encoder_parameters(&cparameters);
    cparameters.decod_format = PNG_DFMT;
    cparameters.cod_format = J2K_CFMT;

    const OPJ_COLOR_SPACE color_space = OPJ_CLRSPC_SRGB; //OPJ_CLRSPC_GRAY;
    unsigned int numcomps = 4;
    unsigned int i;
    unsigned int image_width = 256;
    unsigned int image_height = 256;
    unsigned int subsampling_dx;
    unsigned int subsampling_dy;
    
    opj_image_cmptparm_t cmptparm[6]; // max 4 components
    memset(&cmptparm[0], 0, 4 * sizeof(opj_image_cmptparm_t));
    subsampling_dx = cparameters.subsampling_dx;
    subsampling_dy = cparameters.subsampling_dy;

    for (int i = 0; i < numcomps; i++) {
        cmptparm[i].prec = 8;
        cmptparm[i].sgnd = 0;
        cmptparm[i].dx = (OPJ_UINT32)subsampling_dx;
        cmptparm[i].dy = (OPJ_UINT32)subsampling_dy;
        cmptparm[i].w = image_width;
        cmptparm[i].h = image_height;
    }

    opj_image_t *image = opj_image_create((OPJ_UINT32)numcomps, &cmptparm[0], color_space);
   
    // init data to random? or to input image?
    /*
    for (i = 0; i < image_width * image_height; i++) {
        unsigned int compno;
        for (compno = 0; compno < numcomps; compno++) {
            image->comps[compno].data[i] = data[i];
        }
    }*/

    // CREATE CODEC
    OPJ_CODEC_FORMAT eCodecFormat =  OPJ_CODEC_J2K;
    opj_codec_t *l_codec = opj_create_compress(eCodecFormat);
    opj_set_info_handler(l_codec, InfoCallback, NULL);
    opj_set_warning_handler(l_codec, WarningCallback, NULL);
    opj_set_error_handler(l_codec, ErrorCallback, NULL);

    // ENCODER
    if (!opj_setup_encoder(l_codec, &cparameters, image))
    {
        printf("!!!!! setup_encoder failed\n");
    }

    // STREAM
    // if true, the stream is an input stream, otherwise an output stream 
    opj_stream_t *l_stream = opj_stream_create(1024, OPJ_FALSE);
    MemFile memFile;
    memFile.pabyData = data;
    memFile.nLength = len;
    memFile.nCurPos = 0;
    opj_stream_set_user_data_length(l_stream, len);
    opj_stream_set_read_function(l_stream, ReadCallback);
    opj_stream_set_seek_function(l_stream, SeekCallback);
    opj_stream_set_skip_function(l_stream, SkipCallback);
    opj_stream_set_user_data(l_stream, &memFile, NULL);
    if (!l_stream)
    {
        printf("!!!!! l_stream: opj_stream_create_default_file_stream failed\n");
        return 1;
    }

    // COMPRESS
    bSuccess = opj_start_compress(l_codec, image, l_stream);
    if (!bSuccess)
    {
        printf("!!!! start compress fails foof foof foof\n");
        return 1;
    }
    bSuccess = opj_encode(l_codec, l_stream);
    bSuccess = opj_end_compress(l_codec, l_stream);

    opj_stream_destroy(l_stream);
    opj_destroy_codec(l_codec);
    opj_image_destroy(image);

    return 0;
}
