#include <stdint.h>
#include "guetzli/jpeg_data.h"
#include "guetzli/jpeg_data_reader.h"
#include "guetzli/jpeg_data_decoder.h"
#include "guetzli/processor.h"
#include "guetzli/output_image.h"

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
  std::string jpeg_data(reinterpret_cast<const char*>(data), size);

  // Ignore large images, to prevent timeouts.
  guetzli::JPEGData jpg_header;
  if (!guetzli::ReadJpeg(data, size, guetzli::JPEG_READ_HEADER, &jpg_header)) {
    return 0;
  }

  static constexpr int kMaxPixels = 10000;
  if (static_cast<int64_t>(jpg_header.width) * jpg_header.height > kMaxPixels) {
    return 0;
  }

  int width = jpg_header.width, height = jpg_header.height;
  
  guetzli::JPEGData jpg;
  if (!guetzli::ReadJpeg(jpeg_data, guetzli::JPEG_READ_ALL, &jpg)) {
    return 0;
  }

  std::vector<uint8_t> rgb = DecodeJpegToRGB(jpg);

  // TODO(robryk): Use nondefault parameters.
  guetzli::Params params;
  std::string jpeg_out;
  (void)guetzli::Process(params, nullptr, rgb, width, height, &jpeg_out);
  // TODO(robryk): Verify output distance if Process() succeeded.

  guetzli::OutputImage img(width, height);
  img.CopyFromJpegData(jpg);

  guetzli::DownsampleImage(img);


  return 0;
}