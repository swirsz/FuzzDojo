#include <stdint.h>
#include "guetzli/jpeg_data.h"
#include "guetzli/jpeg_data_reader.h"
#include "guetzli/processor.h"

#include "guetzli/preprocess_downsample.h"

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
  size_t actual_size = size - size % 3;
  const std::vector<uint8_t> rgb_in(data, data + actual_size);
  const int w = actual_size / 3;
  const int h = 1;
  std::vector<std::vector<float>> yuv = guetzli::RGBToYUV420(rgb_in, w, h);
  guetzli::PreProcessChannel(w, h, 2, 1.3, 1.5, true, true, yuv);
  return 0;
}




