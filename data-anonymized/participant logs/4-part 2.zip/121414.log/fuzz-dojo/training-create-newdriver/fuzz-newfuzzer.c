
/***
  This file is part of avahi.

  avahi is free software; you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as
  published by the Free Software Foundation; either version 2.1 of the
  License, or (at your option) any later version.

  avahi is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General
  Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with avahi; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
  USA.
***/

#include <stdint.h>
#include <string.h>

#include "avahi-common/malloc.h"
#include "avahi-core/dns.h"
#include "avahi-core/log.h"

void log_function(AvahiLogLevel level, const char *txt) {}

int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
avahi_set_log_function(log_function);
    // Create a DNS packet with enough space
    AvahiDnsPacket* packet = avahi_dns_packet_new(size + AVAHI_DNS_PACKET_EXTRA_SIZE);
    if (!packet)
        return 0;
    // Copy input data to packet
    memcpy(AVAHI_DNS_PACKET_DATA(packet), data, size);
    packet->size = size;
    // Set up parameters for avahi_dns_packet_new_reply
    unsigned mtu = size > 0 ? (data[0] % 1500) + 512 : 512; // MTU between 512 and 2012
    int copy_queries = size > 1 ? (data[1] % 2) : 0; // Copy queries flag
    int aa = size > 2 ? (data[2] % 2) : 0; // Authoritative Answer flag
    // Create a reply packet using avahi_dns_packet_new_reply
    AvahiDnsPacket* reply = avahi_dns_packet_new_reply(packet, mtu, copy_queries, aa);
    // Clean up
    if (reply)
        avahi_dns_packet_free(reply);
    avahi_dns_packet_free(packet);
    return 0;


}
