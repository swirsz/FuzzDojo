/*
# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
###############################################################################
*/

#include "bzlib.h"
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stddef.h>
#include <unistd.h>
#include <stdio.h>
#include <stdbool.h>
#include <fcntl.h>

int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
if (size < 1) return 0; // Avoid empty input

    int fd = open("/tmp/fuzztest.bz2", O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (fd < 0) return 0;

    BZFILE *bzfile = BZ2_bzdopen(fd, "w9"); // Write mode, max compression
    if (!bzfile) {
        close(fd);
        return 0;
    }

    int ret = BZ2_bzwrite(bzfile, (void *)data, size); // Corrected call
    BZ2_bzclose(bzfile); // Closes fd internally
    remove("/tmp/fuzztest.bz2"); // Clean up
    return 0;
}
