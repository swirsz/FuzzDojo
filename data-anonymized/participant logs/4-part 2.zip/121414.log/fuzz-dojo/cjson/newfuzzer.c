#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

#include "../cJSON.h"

int LLVMFuzzerTestOneInput(const uint8_t* data, size_t size) {
    if (size < 1) return 0;
    
    char *json_str = (char*)malloc(size + 1);
    if (!json_str) return 0;
    memcpy(json_str, data, size);
    json_str[size] = '\0';
    
    cJSON *json = cJSON_Parse(json_str);
    free(json_str);
    if (!json) return 0;
    
    // Test array operations
    if (cJSON_IsArray(json)) {
        int array_size = cJSON_GetArraySize(json);
        int i;
        for (i = 0; i < array_size && i < 10; i++) {
            cJSON *item = cJSON_GetArrayItem(json, i);
            if (item) {
                cJSON_IsNumber(item);
                cJSON_IsString(item);
                cJSON_IsBool(item);
            }
        }
    }
    
    // Test object operations
    if (cJSON_IsObject(json)) {
        cJSON *child = json->child;
        while (child) {
            cJSON_GetObjectItem(json, child->string);
            cJSON_HasObjectItem(json, child->string);
            child = child->next;
        }
    }
    
    // Test printing
    char *str = cJSON_Print(json);
    if (str) free(str);
    
    str = cJSON_PrintUnformatted(json);
    if (str) free(str);
    
    // Test comparison
    cJSON *json2 = cJSON_Duplicate(json, 1);
    if (json2) {
        cJSON_Compare(json, json2, 1);
        cJSON_Delete(json2);
    }
    
    cJSON_Delete(json);
    return 0;
}

#ifdef __cplusplus
}
#endif
